# imageDenoizerAPI

Download OpenCV-MinGW-Build-OpenCV-4-1-0 here : https://github.com/huihut/OpenCV-MinGW-Build/archive/refs/tags/OpenCV-4.1.0.zip
Copy content to C:\opencv-mingw